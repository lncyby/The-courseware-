#!/usr/bin/python

a = 4
def fun():
    a = 1
    print "in:",a

fun()
print "out:",a
