#!/usr/bin/python

def fun(a,b):
    print "This  is a function!!"
    return a + b
    print "function over!!"

r = fun(1,2)

print r

print fun(3,4)
