#!/usr/bin/python

def fun(a,b):
    return a+b,a-b,a*b,a/b

r = fun(6,3)

print r
