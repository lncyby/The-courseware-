#!/usr/bin/python

class Test():
    a = 1

    def fun(self):
        print "hello class"
        print self.a


test = Test()

print test.a

test.fun()

print Test.a
#Test.fun()
