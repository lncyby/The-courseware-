#!/usr/bin/python

'''This is a module'''
print "module1...."

class A():
    print "module1 -> class A"
    def a(self):
        print "module1->class A->def a"


def B():
    print "module1->def B"
