#!/usr/bin/python

class _C():
    print "***********"
    def c(self):
        print "module2->C->c"

class D():
    print "++++++++++++"
    def d(self):
        print "module2->D->d"
