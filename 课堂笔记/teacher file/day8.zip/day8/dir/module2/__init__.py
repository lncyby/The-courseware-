#!/usr/bin/python

print "dir dir dir"
