#!/usr/bin/python

#import module1
from module1 import A,B
from module2 import *

#object1 = module1.A()
object1 = A()

object1.a()

B()

object2 = _C()
object2.c()
