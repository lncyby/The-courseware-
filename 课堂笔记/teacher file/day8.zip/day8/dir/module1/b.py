#!/usr/bin/python


print "hello world"
a = 3

def fun():
    pass
