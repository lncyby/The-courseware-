#!/usr/bin/python

#import module2.module1
from module2 import module1


#object1  = module2.module1.A()
object1  = module1.A()
object1.a()

