#!/usr/bin/python
#coding=utf-8

class MyError(Exception):
    pass

try:
    s = "hello"
    if s is None:
        print "s 是空对象 "
        raise MyError("hahaha")
    print len(s)
except MyError as X:
    print "空对象没有长度"
    print X.args


