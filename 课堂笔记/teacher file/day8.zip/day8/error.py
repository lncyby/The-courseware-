#!/usr/bin/python

def div(a,b):
    return a / b

result = div(3,0)

print result

print "test over"
