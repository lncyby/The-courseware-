#!/usr/bin/python

class Test:

    def __init__(self,name):
        self.__name = name

    def setName(self,name):
        self.__name = name

    def getName(self):
        return self.__name


t = Test('zhangsan')

#print t.__name

print t.getName()

t.setName("lisi")
print t.getName()
