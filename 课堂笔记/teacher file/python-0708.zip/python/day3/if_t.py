#!/usr/bin/python

if False:
    print "hello world"
    print "hello world"
    print "hello world"
    print "hello world"
    print "hello world"
    print "hello world"
    print "hello world"
    print "hello world"
    print "hello world"

