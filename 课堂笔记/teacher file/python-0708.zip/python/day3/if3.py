#!/usr/bin/python
#coding=utf-8

# if....elif..else

a = input()

if a > 0:
    print "a > 0"
elif a == 0:
    print "a == 0"
else:
    print "a < 0"

