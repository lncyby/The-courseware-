#!/usr/bin/python
#coding=utf-8

a = input()

if 10 < a < 100:
    print "10 < a < 100"
