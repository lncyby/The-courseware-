#!/usr/bin/python
#coding=utf-8

# if....else

a = input()

if a > 0:
    print "a > 0"
else:
    print "a <= 0"

