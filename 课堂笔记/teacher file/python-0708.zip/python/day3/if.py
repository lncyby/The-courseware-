#!/usr/bin/python
#coding=utf-8

#简单的if语句

a = input()

if a > 0:
    print "a > 0"
