#!/usr/bin/python


print "hello world",
print "hello"
