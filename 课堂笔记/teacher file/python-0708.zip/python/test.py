#!/usr/bin/python
#coding=utf-8

'''This is a test'''

print ('''I love China and
      China love me''')


s =  "我爱你中国，中国万岁!"
s1 = "我爱美国"
s2 = "呵呵"

print (s)
print (s1)
print (s2)
