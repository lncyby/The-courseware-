#!/usr/bin/python

for i in range(5):
    for j in range(5):
        print j,

    print ""
