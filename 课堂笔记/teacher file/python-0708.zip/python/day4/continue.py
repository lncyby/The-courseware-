#!/usr/bin/python

i = 0

while i < 10:
    i += 1
    if i == 5:
#        break
        continue
    print i
else:
    print "+++++++++++++++"

while True:
    pass
