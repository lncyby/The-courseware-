#!/usr/bin/python


flag = 1

for num in range(5,100):
    for i in range(2,num / 2):
        if num % i == 0:
            flag = 0
            break
        else:
            flag = 1

    if flag == 1:
        print "%d"%num
