#!/usr/bin/python

i = 0

while i < 10:
    print i,'',
    i += 1
    if i == 5:
        break
else:
    print "game over"

print "++++++++++++"
