#!/usr/bin/python

for 1 in []:
    print "hello"
