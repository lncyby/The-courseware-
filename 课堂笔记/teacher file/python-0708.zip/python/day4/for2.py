#!/usr/bin/python

for (i,j,k) in [(1,2,7),(3,4,8),(5,6,9)]:
    print i,j,k
