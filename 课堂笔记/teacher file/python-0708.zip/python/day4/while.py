#!/usr/bin/python

i = 1
s = 0

while i <= 100:
    s += i
    i += 1

print "s = %d"%s
