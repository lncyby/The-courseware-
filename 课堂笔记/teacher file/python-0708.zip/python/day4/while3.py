#!/usr/bin/python

import time

while True:
    time.sleep(1)
    print "hahahhaah"
