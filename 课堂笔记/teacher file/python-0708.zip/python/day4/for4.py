#!/usr/bin/python

s = 0

for i in range(1,101):
    s += i

print s
