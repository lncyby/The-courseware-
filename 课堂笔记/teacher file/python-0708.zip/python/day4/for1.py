#!/usr/bin/python

l = [1,2,3,4,5,6,7,8]

for i in l:
    print i,
    if i == 3:
        break
else:
    print "game over"

print "++++++++++++++"
