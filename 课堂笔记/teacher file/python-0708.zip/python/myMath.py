#!/usr/bin/python


import math

a = math.pow(2,4)

b = math.sqrt(9)

print a
print b
