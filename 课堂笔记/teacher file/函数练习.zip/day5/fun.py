#!/usr/bin/python


def fun():
    print "hello world"

fun()

print fun
print type(fun)
