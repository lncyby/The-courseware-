#!/usr/bin/python

def fun():
    print "hello world"

print fun()

r = fun()
print r
