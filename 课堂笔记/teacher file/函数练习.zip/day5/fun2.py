#!/usr/bin/python

def fun(a):
    a = a[:]
    a[3] = 100
    print a


l = [1,2,3,4,5]

print l

fun(l)
print "++++++++++++++++++++++"
print l
